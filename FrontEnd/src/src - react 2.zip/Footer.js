function Footer(){
    return (
        <div class="footer">
        <p>Ethiopia</p>
        <div>
            <div>
                <a href="">About</a>
                <a href="">Advertising</a>
                <a href="">Business</a>
                <a href="">How Search works </a>
            </div>
            <div>
                <a href="">Privacy</a>
                <a href="">Terms</a>
                <a href="">Settings</a>
            </div>
        </div>
        
    </div>
    )
}

export default Footer