function Button(props){
    return <button>{props.data}</button>
}

export default Button