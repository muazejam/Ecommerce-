import google from './google.png'
import { homeContext } from './App'
import { useContext } from 'react'
import logo from './shopping-logo.png'
import Button from './Button'
import { appContext } from './App'
// import { Link } from 'react-router-dom'

function Header(){
    const {data} = useContext(appContext)
    
    return (
        <header>
        <img src={logo} alt="" />
        <div>
            <div class="cart">
                <i class="fa fa-cart-plus"></i>
                <div>
                    <span id="cart-count">{data.length}</span>
                </div>
            </div>
            {/* <Link to="/login">Login</Link>  */}
        </div>
    </header>
    )
}


export default Header