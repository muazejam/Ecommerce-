import React from 'react'
import { Outlet } from 'react-router-dom'
import Header from './Header'
import Main from './Main'

export default function Root() {
  return (
    <div>
      <Header />
      <Outlet />
      <Main />
      {/* <h1>this is a footer</h1> */}
    </div>
  )
}
