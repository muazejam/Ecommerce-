// import logo from './logo.svg';
import React, {useState} from 'react';
// import './style1.css'

import './style.css';

import Header from './Header';
import Footer from './Footer';
import Button from './Button';
import UnorderedList from './UnorderedList';
import Main from './Main';
import {createContext} from 'react'

import Profile from './Profile';
import Alert from './Alert';
import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom"
import Root from './Root';
import Login from './Login';


const router = createBrowserRouter([
  {
    path: "/",
    element: <Root />,
    children: [
      {
        path: 'profile',
        element: <h1>My Profile</h1>
      },
      {
        path: 'login',
        element: <Login />
      }
    ]
  },
  
  {
    path: '*',
    element: <h2>Sorry is page is not found</h2>
  }
]);



// function click() {

// }

const click = function(x){
  return 3
}

const click2 = (x) =>  x * 2

const y = click2(4)


export const appContext = createContext()

function App() {
 const [cart, setCart] = useState([])

  return (
    <appContext.Provider value={{
      data: cart,
      setData: setCart
    }}>
      <Header  />
      <Main />
    </appContext.Provider>
  )
}

// component
// jsx


export default App;
