function Header(){
    return <h1>This is a header</h1>
}

export default Header